#!/bin/sh

touch AUTHORS; chmod 640 AUTHORS
